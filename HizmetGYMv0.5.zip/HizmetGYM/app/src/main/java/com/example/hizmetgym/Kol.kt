package com.example.hizmetgym

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity

class Kol :AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.kol)
        val logo = findViewById<ImageButton>(R.id.exercise13)
        logo.setOnClickListener {
            startActivity(Intent(this, RopeCableHammerCurl::class.java))
        }
        val logo2 = findViewById<ImageButton>(R.id.exercise12)
        logo2.setOnClickListener {
            startActivity(Intent(this, ZBarCurl::class.java))
        }
        val logo3 = findViewById<ImageButton>(R.id.exercise11)
        logo3.setOnClickListener {
            startActivity(Intent(this, DumbbellSpiderCurl::class.java))
        }
        val logo4 = findViewById<ImageButton>(R.id.exercise10)
        logo4.setOnClickListener {
            startActivity(Intent(this, DumbbellBenchPress::class.java))
        }
        val logo5 = findViewById<ImageButton>(R.id.exercise9)
        logo5.setOnClickListener {
            startActivity(Intent(this, CableRopePushDown::class.java))
        }
        val logo6 = findViewById<ImageButton>(R.id.exercise8)
        logo6.setOnClickListener {
            startActivity(Intent(this, StraightBarPushDown::class.java))
        }
        val logo7 = findViewById<ImageButton>(R.id.exercise3)
        logo7.setOnClickListener {
            startActivity(Intent(this, DumbbellCrossBodyHammerCurl::class.java))
        }
        findViewById<Button>(R.id.Takvim)
            .setOnClickListener {
                startActivity(Intent(this,Takvim::class.java))
            }
        findViewById<Button>(R.id.sss)
            .setOnClickListener {
                startActivity(Intent(this,sss::class.java))
            }
    }}