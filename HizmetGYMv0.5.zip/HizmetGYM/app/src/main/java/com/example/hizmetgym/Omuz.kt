package com.example.hizmetgym

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity

class Omuz :AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.omuz)
        val logo = findViewById<ImageButton>(R.id.exercise13)
        logo.setOnClickListener {
            startActivity(Intent(this, DumbbellLateralRaise::class.java))
        }
        val logo2 = findViewById<ImageButton>(R.id.exercise3)
        logo2.setOnClickListener {
            startActivity(Intent(this, MachineOverheadShoulderPress ::class.java))
        }
        val logo3 = findViewById<ImageButton>(R.id.exercise11)
        logo3.setOnClickListener {
            startActivity(Intent(this, SeatedDumbellOverheadShoulderPress::class.java))
        }
        val logo4 = findViewById<ImageButton>(R.id.exercise12)
        logo4.setOnClickListener {
            startActivity(Intent(this, DumbbellLayingReverseFly::class.java))
        }
        findViewById<Button>(R.id.Takvim)
            .setOnClickListener {
                startActivity(Intent(this,Takvim::class.java))
            }
        findViewById<Button>(R.id.sss)
            .setOnClickListener {
                startActivity(Intent(this,sss::class.java))
            }
    }}