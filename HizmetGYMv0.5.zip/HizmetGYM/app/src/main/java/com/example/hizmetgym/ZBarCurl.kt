package com.example.hizmetgym

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class ZBarCurl: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.zbarcurl)
}}