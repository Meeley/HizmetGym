package com.example.hizmetgym

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity

class MainScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_screen)
        val logo = findViewById<ImageButton>(R.id.Muscle)
        logo.setOnClickListener {
            startActivity(Intent(this, exercises::class.java))
    }
}}